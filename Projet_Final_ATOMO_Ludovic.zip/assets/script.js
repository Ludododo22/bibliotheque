// assets/script.js
// Accessible flash message (if set in session) via progressive enhancement could be added.
// Minimal JS for demo: close buttons, etc. Kept light for eco‑conception.
