</main>
<footer class="site-footer">
  <div class="container small">
    <p>© <?= date('Y') ?> BiblioWeb — Projet d'apprentissage (HTML/CSS/JS/PHP/MySQL).</p>
  </div>
</footer>
</body>
</html>
